﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Passeggero
{
    private string nome;
    private int eta;

    public Passeggero (string nome, int eta)
    {
        this.nome = nome;
        this.eta = eta;
    }

    public string DimmiNome ()
    {
        return nome;
    }

    public int DimmiEta ()
    {
        return eta;
    }
}