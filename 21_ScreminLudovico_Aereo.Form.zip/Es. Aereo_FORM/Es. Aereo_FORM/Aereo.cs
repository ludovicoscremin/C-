﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Aereo
{
    public Passeggero[] arrPasseggeri;

    public Aereo ()
    {
        arrPasseggeri = new Passeggero[200];
    }

    // restituire true se il posto è libero, false se è occupato
    // Ipotizziamo che 
    public bool AssegnaPosto(Passeggero p, int posto)
    {
        bool esito = false;
        int i = posto - 1;

        if (arrPasseggeri[i] == null)
        {
            esito = true;
            arrPasseggeri[i] = p;
        }

        return esito;
    }
    public int ContaPostiLiberi ()
    {
        int cont = 0;

        // 1000 è il valore che ho assegnato alle dimensione dell'array nel costruttore
        for (int i = 0; i < 200; i++)
        {
            if (arrPasseggeri[i] == null)
            {
                cont++;
            }
        }
        return cont;
    }

    public int ContaPostiAssegnati ()
    {
        int cont = 0;

        for (int i = 0; i < 200; i++)
        {
            if (arrPasseggeri[i] != null)
            {
                cont++;
            }
        }
        return cont;

    }

    public int ContaMinorenni ()
    {
        int cont = 0;

        for (int i = 0;i < 200; i++)
        {
            // dobbiamo escludere i posti vuoti
            if ( arrPasseggeri[i] != null)
            {
                if (arrPasseggeri[i].DimmiEta () < 18)
                {
                    cont++;
                }
            }
        }
        return cont;
    }

    public int EtaDelPiuGiovane ()
    {
        bool cond = true;
        int t = 0;
        int min = 0;
        int etaDelPiuGiovane = 0;

        // prima cerca la prima persona che ha un posto nell'aereo.
        // La considero inizialmente come passeggero più giovane,
        // e poi controllo se c'è qualcuno con un'età minore.
        while (t < 200 && cond == true)
        {
            if (arrPasseggeri[t] != null)
            {
                cond = false;
                min = arrPasseggeri[t].DimmiEta ();
            }
            t++;
        }

        for (int i = 0; i < 200; i++)
        {
            if (arrPasseggeri[i].DimmiEta() < min)
            {
                etaDelPiuGiovane  = arrPasseggeri[i].DimmiEta();
            }
        }
        return etaDelPiuGiovane;
    }

    public int EtaDelPiuVeccio ()
    {
        bool cond = true;
        int t = 0;
        int max = 0;
        int etaDelPiuVecchio = 0;

        while (t < 200 && cond == true)
        {
            if (arrPasseggeri[t] != null)
            {
                cond = false;
                max = arrPasseggeri[t].DimmiEta();
            }
            t++;
        }

        for (int i = 0; i < 200; i++)
        {
            if (arrPasseggeri[i].DimmiEta() > max)
            {
                etaDelPiuVecchio = arrPasseggeri[i].DimmiEta();
            }
        }
        return etaDelPiuVecchio;
    }

    public bool SpostaPasseggero (int posIniziale, int posFinale)
    {
        // Inanzitutto bisogna controllare che il passeggero venga spostato in un posto libero.
        // La logica delle righe di codice di questo metodo si basa sull'assegnare il nuovo posto
        // richiesto dal passeggero, solo se questo è libero (quindi disponibile).
        // Dato che il metodo in input riceve anche la posizione iniziale, ho ipotizzato che questo
        // dato ci permetta di identificare il passegger che ha richiesto il cambio di posto.
        // Il metodo restituisde true se è stato effettuato il cambio di posto desiderato dal
        // passeggero in questione.
        bool cond = false;

        if (arrPasseggeri[posFinale] == null)
        {
            cond = true;
            arrPasseggeri[posFinale] = arrPasseggeri[posIniziale];
        }
        return cond;
    }

    public bool EliminaPasseggero (int posto)
    {
        bool cond = false;

        if (arrPasseggeri[posto] != null)
        {
            cond = true;
            arrPasseggeri[posto] = null;
        }
        return cond;
    }

    public string InfoPasseggero (int posto)
    {
        return arrPasseggeri[posto].DimmiNome() + arrPasseggeri[posto].DimmiEta();
    }

    public Passeggero[] ElencoMinorenni ()
    {
        Passeggero[] arrMinorenni = new Passeggero[200];
        int cont = 0;

        for (int i = 0; i < 200; i++)
        {
            if (arrPasseggeri[i]!=null)
            {
                if (arrPasseggeri[i].DimmiEta() < 18)
                {
                    arrMinorenni[cont] = arrPasseggeri[i];
                    cont++;
                }
            }
        }
        return arrMinorenni;
    }

    public int CercaPasseggero (string nome)
    {
        // se più passeggeri hanno lo stesso nome, restituisco il posto del primo
        bool cond = false;
        int t = 0;
        while (t < 1000 && cond == false)
        {
            if (arrPasseggeri[t].DimmiNome() == nome)
            {
                cond = true;
            }
        }
        return t;
    }
}