namespace Es._Aereo_FORM
{
    public partial class Form1 : Form
    {
        private Aereo a;
        private Passeggero p;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNomePasseggero_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCreaPasseggero_Click(object sender, EventArgs e)
        {
            string nomePasseggero = Convert.ToString(txtNomePasseggero.Text);
            int etaPasseggero = Convert.ToInt32(txtEtaPasseggero.Text);
            p = new Passeggero(nomePasseggero, etaPasseggero);
        }

        private void txtEtaPasseggero_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int pstLiberi = a.ContaPostiLiberi();
            lblOutputPostiLiberi.Text = "" + pstLiberi;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void btnAssegnaPosto_Click(object sender, EventArgs e)
        {
            int posto = Convert.ToInt32(txtInputPosto.Text);
            bool esito = a.AssegnaPosto(p, posto);
            if (esito == true)
            {
                lblOutputAssegnaPosto.Text = "L'assegnamento del posto � stato eseguito!";
            }
            else
            {
                lblOutputAssegnaPosto.Text = "Il posto � gi� occupato!";
            }
        }

        private void btnInserisciNuoviDati_Click(object sender, EventArgs e)
        {
            txtNomePasseggero.Clear();
            txtEtaPasseggero.Clear();
        }

        private void btnContaPostiAssegnati_Click(object sender, EventArgs e)
        {
            int pstAssegnati = a.ContaPostiAssegnati();
            lblOutputPostiAssegnati.Text = "" + pstAssegnati;
        }

        private void btnContaMinorenni_Click(object sender, EventArgs e)
        {
            int cntMinorenni = a.ContaMinorenni();
            lblOutputContaMinorenni.Text = "" + cntMinorenni;
        }

        private void btnTrovaEtaDelPiuVecchio_Click(object sender, EventArgs e)
        {
            int etpiVecchio = a.EtaDelPiuVeccio();
            lblOutputEtaDelPiuVecchio.Text = "" + etpiVecchio;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Passeggero[] arrMinrnni = new Passeggero [200];          
            arrMinrnni = a.ElencoMinorenni();
            lblOutputElencoDeiPasseggeriMinorenni.Text = "" + arrMinrnni;
        }

        private void btnTrovaEtaDelPiuGiovane_Click(object sender, EventArgs e)
        {
            int etdpiugvn = a.EtaDelPiuGiovane();
            lblOutputEtaDelPiuGiovane.Text = "" + etdpiugvn;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int postoDaEliminare = Convert.ToInt32(lblEliminaPasseggero.Text);
            a.EliminaPasseggero(postoDaEliminare);
        }

        private void label1_Click_4(object sender, EventArgs e)
        {

        }

        private void btnCercaPasseggero_Click(object sender, EventArgs e)
        {
            int psznpassg = Convert.ToInt32(txtPasseggeroDaCercare.Text);
            lblOutputPasseggeroDaCercare.Text = "" + psznpassg;
        }
    }
}
