﻿namespace Es._Aereo_FORM
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNomePasseggero = new Label();
            txtNomePasseggero = new TextBox();
            lblEtaPasseggero = new Label();
            txtEtaPasseggero = new TextBox();
            btnCreaPasseggero = new Button();
            btnContaPostiLiberi = new Button();
            btnContaPostiAssegnati = new Button();
            btnContaMinorenni = new Button();
            btnTrovaEtaDelPiuGiovane = new Button();
            btnTrovaEtaDelPiuVecchio = new Button();
            button1 = new Button();
            lblPostiLiberi = new Label();
            lblOutputPostiLiberi = new Label();
            lbltxtPostiAssegnati = new Label();
            lblOutputPostiAssegnati = new Label();
            lbltxtNumeroDiMinorenni = new Label();
            lblOutputContaMinorenni = new Label();
            btnAssegnaPosto = new Button();
            lblPosto = new Label();
            txtInputPosto = new TextBox();
            btnInserisciNuoviDati = new Button();
            lblOutputAssegnaPosto = new Label();
            btnEliminaPasseggero = new Button();
            lblEliminaPasseggero = new Label();
            txtInputPostoDaEliminare = new TextBox();
            lblEtaDelPiuVecchio = new Label();
            lblOutputEtaDelPiuVecchio = new Label();
            lblElencoDeiPasseggeriMinorenni = new Label();
            lblOutputElencoDeiPasseggeriMinorenni = new Label();
            lblEtaDelPiuGiovane = new Label();
            lblOutputEtaDelPiuGiovane = new Label();
            lblPasseggeroDaCercare = new Label();
            txtPasseggeroDaCercare = new TextBox();
            btnCercaPasseggero = new Button();
            lblOutputPasseggeroDaCercare = new Label();
            SuspendLayout();
            // 
            // lblNomePasseggero
            // 
            lblNomePasseggero.AutoSize = true;
            lblNomePasseggero.Location = new Point(98, 71);
            lblNomePasseggero.Name = "lblNomePasseggero";
            lblNomePasseggero.Size = new Size(65, 25);
            lblNomePasseggero.TabIndex = 0;
            lblNomePasseggero.Text = "Nome:";
            lblNomePasseggero.Click += label1_Click;
            // 
            // txtNomePasseggero
            // 
            txtNomePasseggero.Location = new Point(265, 71);
            txtNomePasseggero.Name = "txtNomePasseggero";
            txtNomePasseggero.Size = new Size(150, 31);
            txtNomePasseggero.TabIndex = 1;
            txtNomePasseggero.TextChanged += txtNomePasseggero_TextChanged;
            // 
            // lblEtaPasseggero
            // 
            lblEtaPasseggero.AutoSize = true;
            lblEtaPasseggero.Location = new Point(98, 124);
            lblEtaPasseggero.Name = "lblEtaPasseggero";
            lblEtaPasseggero.Size = new Size(40, 25);
            lblEtaPasseggero.TabIndex = 2;
            lblEtaPasseggero.Text = "Età:";
            // 
            // txtEtaPasseggero
            // 
            txtEtaPasseggero.Location = new Point(265, 118);
            txtEtaPasseggero.Name = "txtEtaPasseggero";
            txtEtaPasseggero.Size = new Size(150, 31);
            txtEtaPasseggero.TabIndex = 3;
            txtEtaPasseggero.TextChanged += txtEtaPasseggero_TextChanged;
            // 
            // btnCreaPasseggero
            // 
            btnCreaPasseggero.Location = new Point(94, 234);
            btnCreaPasseggero.Name = "btnCreaPasseggero";
            btnCreaPasseggero.Size = new Size(229, 34);
            btnCreaPasseggero.TabIndex = 4;
            btnCreaPasseggero.Text = "Crea Passeggero";
            btnCreaPasseggero.UseVisualStyleBackColor = true;
            btnCreaPasseggero.Click += btnCreaPasseggero_Click;
            // 
            // btnContaPostiLiberi
            // 
            btnContaPostiLiberi.Location = new Point(571, 71);
            btnContaPostiLiberi.Name = "btnContaPostiLiberi";
            btnContaPostiLiberi.Size = new Size(224, 34);
            btnContaPostiLiberi.TabIndex = 5;
            btnContaPostiLiberi.Text = "Conta posti liberi";
            btnContaPostiLiberi.UseVisualStyleBackColor = true;
            btnContaPostiLiberi.Click += button1_Click;
            // 
            // btnContaPostiAssegnati
            // 
            btnContaPostiAssegnati.Location = new Point(571, 124);
            btnContaPostiAssegnati.Name = "btnContaPostiAssegnati";
            btnContaPostiAssegnati.Size = new Size(224, 34);
            btnContaPostiAssegnati.TabIndex = 6;
            btnContaPostiAssegnati.Text = "Conta posti assegnati";
            btnContaPostiAssegnati.UseVisualStyleBackColor = true;
            btnContaPostiAssegnati.Click += btnContaPostiAssegnati_Click;
            // 
            // btnContaMinorenni
            // 
            btnContaMinorenni.Location = new Point(571, 175);
            btnContaMinorenni.Name = "btnContaMinorenni";
            btnContaMinorenni.Size = new Size(224, 34);
            btnContaMinorenni.TabIndex = 7;
            btnContaMinorenni.Text = "Conta minorenni";
            btnContaMinorenni.UseVisualStyleBackColor = true;
            btnContaMinorenni.Click += btnContaMinorenni_Click;
            // 
            // btnTrovaEtaDelPiuGiovane
            // 
            btnTrovaEtaDelPiuGiovane.Location = new Point(880, 175);
            btnTrovaEtaDelPiuGiovane.Name = "btnTrovaEtaDelPiuGiovane";
            btnTrovaEtaDelPiuGiovane.Size = new Size(358, 34);
            btnTrovaEtaDelPiuGiovane.TabIndex = 8;
            btnTrovaEtaDelPiuGiovane.Text = "Trova età del più giovane";
            btnTrovaEtaDelPiuGiovane.UseVisualStyleBackColor = true;
            btnTrovaEtaDelPiuGiovane.Click += btnTrovaEtaDelPiuGiovane_Click;
            // 
            // btnTrovaEtaDelPiuVecchio
            // 
            btnTrovaEtaDelPiuVecchio.Location = new Point(880, 71);
            btnTrovaEtaDelPiuVecchio.Name = "btnTrovaEtaDelPiuVecchio";
            btnTrovaEtaDelPiuVecchio.Size = new Size(358, 34);
            btnTrovaEtaDelPiuVecchio.TabIndex = 9;
            btnTrovaEtaDelPiuVecchio.Text = "Trova età del più vecchio";
            btnTrovaEtaDelPiuVecchio.UseVisualStyleBackColor = true;
            btnTrovaEtaDelPiuVecchio.Click += btnTrovaEtaDelPiuVecchio_Click;
            // 
            // button1
            // 
            button1.Location = new Point(880, 123);
            button1.Name = "button1";
            button1.Size = new Size(358, 34);
            button1.TabIndex = 10;
            button1.Text = "Crea un elenco dei passeggeri minorenni";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // lblPostiLiberi
            // 
            lblPostiLiberi.AutoSize = true;
            lblPostiLiberi.Location = new Point(94, 542);
            lblPostiLiberi.Name = "lblPostiLiberi";
            lblPostiLiberi.Size = new Size(189, 25);
            lblPostiLiberi.TabIndex = 11;
            lblPostiLiberi.Text = "Numero di posti liberi:";
            lblPostiLiberi.Click += label1_Click_1;
            // 
            // lblOutputPostiLiberi
            // 
            lblOutputPostiLiberi.AutoSize = true;
            lblOutputPostiLiberi.Location = new Point(366, 530);
            lblOutputPostiLiberi.Name = "lblOutputPostiLiberi";
            lblOutputPostiLiberi.Size = new Size(0, 25);
            lblOutputPostiLiberi.TabIndex = 12;
            // 
            // lbltxtPostiAssegnati
            // 
            lbltxtPostiAssegnati.AutoSize = true;
            lbltxtPostiAssegnati.Location = new Point(94, 593);
            lbltxtPostiAssegnati.Name = "lbltxtPostiAssegnati";
            lbltxtPostiAssegnati.Size = new Size(225, 25);
            lbltxtPostiAssegnati.TabIndex = 13;
            lbltxtPostiAssegnati.Text = "Numero di posti assegnati:";
            // 
            // lblOutputPostiAssegnati
            // 
            lblOutputPostiAssegnati.AutoSize = true;
            lblOutputPostiAssegnati.Location = new Point(366, 593);
            lblOutputPostiAssegnati.Name = "lblOutputPostiAssegnati";
            lblOutputPostiAssegnati.Size = new Size(0, 25);
            lblOutputPostiAssegnati.TabIndex = 14;
            // 
            // lbltxtNumeroDiMinorenni
            // 
            lbltxtNumeroDiMinorenni.AutoSize = true;
            lbltxtNumeroDiMinorenni.Location = new Point(94, 639);
            lbltxtNumeroDiMinorenni.Name = "lbltxtNumeroDiMinorenni";
            lbltxtNumeroDiMinorenni.Size = new Size(186, 25);
            lbltxtNumeroDiMinorenni.TabIndex = 15;
            lbltxtNumeroDiMinorenni.Text = "Numero di minorenni:";
            // 
            // lblOutputContaMinorenni
            // 
            lblOutputContaMinorenni.AutoSize = true;
            lblOutputContaMinorenni.Location = new Point(327, 650);
            lblOutputContaMinorenni.Name = "lblOutputContaMinorenni";
            lblOutputContaMinorenni.Size = new Size(0, 25);
            lblOutputContaMinorenni.TabIndex = 16;
            // 
            // btnAssegnaPosto
            // 
            btnAssegnaPosto.Location = new Point(94, 313);
            btnAssegnaPosto.Name = "btnAssegnaPosto";
            btnAssegnaPosto.Size = new Size(156, 34);
            btnAssegnaPosto.TabIndex = 17;
            btnAssegnaPosto.Text = "Assegna il posto";
            btnAssegnaPosto.UseVisualStyleBackColor = true;
            btnAssegnaPosto.Click += btnAssegnaPosto_Click;
            // 
            // lblPosto
            // 
            lblPosto.AutoSize = true;
            lblPosto.Location = new Point(98, 173);
            lblPosto.Name = "lblPosto";
            lblPosto.Size = new Size(61, 25);
            lblPosto.TabIndex = 18;
            lblPosto.Text = "Posto:";
            lblPosto.Click += label1_Click_3;
            // 
            // txtInputPosto
            // 
            txtInputPosto.Location = new Point(265, 173);
            txtInputPosto.Name = "txtInputPosto";
            txtInputPosto.Size = new Size(150, 31);
            txtInputPosto.TabIndex = 19;
            // 
            // btnInserisciNuoviDati
            // 
            btnInserisciNuoviDati.Location = new Point(355, 234);
            btnInserisciNuoviDati.Name = "btnInserisciNuoviDati";
            btnInserisciNuoviDati.Size = new Size(178, 34);
            btnInserisciNuoviDati.TabIndex = 20;
            btnInserisciNuoviDati.Text = "Inserisci nuovi dati";
            btnInserisciNuoviDati.UseVisualStyleBackColor = true;
            btnInserisciNuoviDati.Click += btnInserisciNuoviDati_Click;
            // 
            // lblOutputAssegnaPosto
            // 
            lblOutputAssegnaPosto.AutoSize = true;
            lblOutputAssegnaPosto.Location = new Point(343, 320);
            lblOutputAssegnaPosto.Name = "lblOutputAssegnaPosto";
            lblOutputAssegnaPosto.Size = new Size(0, 25);
            lblOutputAssegnaPosto.TabIndex = 21;
            // 
            // btnEliminaPasseggero
            // 
            btnEliminaPasseggero.Location = new Point(1081, 283);
            btnEliminaPasseggero.Name = "btnEliminaPasseggero";
            btnEliminaPasseggero.Size = new Size(176, 34);
            btnEliminaPasseggero.TabIndex = 22;
            btnEliminaPasseggero.Text = "Elimina Passeggero";
            btnEliminaPasseggero.UseVisualStyleBackColor = true;
            btnEliminaPasseggero.Click += button2_Click;
            // 
            // lblEliminaPasseggero
            // 
            lblEliminaPasseggero.AutoSize = true;
            lblEliminaPasseggero.Location = new Point(587, 288);
            lblEliminaPasseggero.Name = "lblEliminaPasseggero";
            lblEliminaPasseggero.Size = new Size(208, 25);
            lblEliminaPasseggero.TabIndex = 23;
            lblEliminaPasseggero.Text = "Passeggero da eliminare:";
            // 
            // txtInputPostoDaEliminare
            // 
            txtInputPostoDaEliminare.Location = new Point(880, 288);
            txtInputPostoDaEliminare.Name = "txtInputPostoDaEliminare";
            txtInputPostoDaEliminare.Size = new Size(150, 31);
            txtInputPostoDaEliminare.TabIndex = 24;
            // 
            // lblEtaDelPiuVecchio
            // 
            lblEtaDelPiuVecchio.AutoSize = true;
            lblEtaDelPiuVecchio.Location = new Point(94, 688);
            lblEtaDelPiuVecchio.Name = "lblEtaDelPiuVecchio";
            lblEtaDelPiuVecchio.Size = new Size(173, 25);
            lblEtaDelPiuVecchio.TabIndex = 25;
            lblEtaDelPiuVecchio.Text = "Età del più vecchhio:";
            lblEtaDelPiuVecchio.Click += label1_Click_4;
            // 
            // lblOutputEtaDelPiuVecchio
            // 
            lblOutputEtaDelPiuVecchio.AutoSize = true;
            lblOutputEtaDelPiuVecchio.Location = new Point(300, 706);
            lblOutputEtaDelPiuVecchio.Name = "lblOutputEtaDelPiuVecchio";
            lblOutputEtaDelPiuVecchio.Size = new Size(0, 25);
            lblOutputEtaDelPiuVecchio.TabIndex = 26;
            // 
            // lblElencoDeiPasseggeriMinorenni
            // 
            lblElencoDeiPasseggeriMinorenni.AutoSize = true;
            lblElencoDeiPasseggeriMinorenni.Location = new Point(94, 731);
            lblElencoDeiPasseggeriMinorenni.Name = "lblElencoDeiPasseggeriMinorenni";
            lblElencoDeiPasseggeriMinorenni.Size = new Size(243, 25);
            lblElencoDeiPasseggeriMinorenni.TabIndex = 27;
            lblElencoDeiPasseggeriMinorenni.Text = "Elenco passeggeri minorenni:";
            // 
            // lblOutputElencoDeiPasseggeriMinorenni
            // 
            lblOutputElencoDeiPasseggeriMinorenni.AutoSize = true;
            lblOutputElencoDeiPasseggeriMinorenni.Location = new Point(384, 731);
            lblOutputElencoDeiPasseggeriMinorenni.Name = "lblOutputElencoDeiPasseggeriMinorenni";
            lblOutputElencoDeiPasseggeriMinorenni.Size = new Size(0, 25);
            lblOutputElencoDeiPasseggeriMinorenni.TabIndex = 28;
            // 
            // lblEtaDelPiuGiovane
            // 
            lblEtaDelPiuGiovane.AutoSize = true;
            lblEtaDelPiuGiovane.Location = new Point(94, 784);
            lblEtaDelPiuGiovane.Name = "lblEtaDelPiuGiovane";
            lblEtaDelPiuGiovane.Size = new Size(167, 25);
            lblEtaDelPiuGiovane.TabIndex = 29;
            lblEtaDelPiuGiovane.Text = "Età del più giovane:";
            // 
            // lblOutputEtaDelPiuGiovane
            // 
            lblOutputEtaDelPiuGiovane.AutoSize = true;
            lblOutputEtaDelPiuGiovane.Location = new Point(327, 784);
            lblOutputEtaDelPiuGiovane.Name = "lblOutputEtaDelPiuGiovane";
            lblOutputEtaDelPiuGiovane.Size = new Size(0, 25);
            lblOutputEtaDelPiuGiovane.TabIndex = 30;
            // 
            // lblPasseggeroDaCercare
            // 
            lblPasseggeroDaCercare.AutoSize = true;
            lblPasseggeroDaCercare.Location = new Point(587, 346);
            lblPasseggeroDaCercare.Name = "lblPasseggeroDaCercare";
            lblPasseggeroDaCercare.Size = new Size(192, 25);
            lblPasseggeroDaCercare.TabIndex = 31;
            lblPasseggeroDaCercare.Text = "Passeggero da cercare:";
            // 
            // txtPasseggeroDaCercare
            // 
            txtPasseggeroDaCercare.Location = new Point(880, 343);
            txtPasseggeroDaCercare.Name = "txtPasseggeroDaCercare";
            txtPasseggeroDaCercare.Size = new Size(150, 31);
            txtPasseggeroDaCercare.TabIndex = 32;
            // 
            // btnCercaPasseggero
            // 
            btnCercaPasseggero.Location = new Point(1081, 346);
            btnCercaPasseggero.Name = "btnCercaPasseggero";
            btnCercaPasseggero.Size = new Size(176, 34);
            btnCercaPasseggero.TabIndex = 33;
            btnCercaPasseggero.Text = "Cerca Passeggero";
            btnCercaPasseggero.UseVisualStyleBackColor = true;
            btnCercaPasseggero.Click += btnCercaPasseggero_Click;
            // 
            // lblOutputPasseggeroDaCercare
            // 
            lblOutputPasseggeroDaCercare.AutoSize = true;
            lblOutputPasseggeroDaCercare.Location = new Point(1320, 349);
            lblOutputPasseggeroDaCercare.Name = "lblOutputPasseggeroDaCercare";
            lblOutputPasseggeroDaCercare.Size = new Size(0, 25);
            lblOutputPasseggeroDaCercare.TabIndex = 34;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1666, 931);
            Controls.Add(lblOutputPasseggeroDaCercare);
            Controls.Add(btnCercaPasseggero);
            Controls.Add(txtPasseggeroDaCercare);
            Controls.Add(lblPasseggeroDaCercare);
            Controls.Add(lblOutputEtaDelPiuGiovane);
            Controls.Add(lblEtaDelPiuGiovane);
            Controls.Add(lblOutputElencoDeiPasseggeriMinorenni);
            Controls.Add(lblElencoDeiPasseggeriMinorenni);
            Controls.Add(lblOutputEtaDelPiuVecchio);
            Controls.Add(lblEtaDelPiuVecchio);
            Controls.Add(txtInputPostoDaEliminare);
            Controls.Add(lblEliminaPasseggero);
            Controls.Add(btnEliminaPasseggero);
            Controls.Add(lblOutputAssegnaPosto);
            Controls.Add(btnInserisciNuoviDati);
            Controls.Add(txtInputPosto);
            Controls.Add(lblPosto);
            Controls.Add(btnAssegnaPosto);
            Controls.Add(lblOutputContaMinorenni);
            Controls.Add(lbltxtNumeroDiMinorenni);
            Controls.Add(lblOutputPostiAssegnati);
            Controls.Add(lbltxtPostiAssegnati);
            Controls.Add(lblOutputPostiLiberi);
            Controls.Add(lblPostiLiberi);
            Controls.Add(button1);
            Controls.Add(btnTrovaEtaDelPiuVecchio);
            Controls.Add(btnTrovaEtaDelPiuGiovane);
            Controls.Add(btnContaMinorenni);
            Controls.Add(btnContaPostiAssegnati);
            Controls.Add(btnContaPostiLiberi);
            Controls.Add(btnCreaPasseggero);
            Controls.Add(txtEtaPasseggero);
            Controls.Add(lblEtaPasseggero);
            Controls.Add(txtNomePasseggero);
            Controls.Add(lblNomePasseggero);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNomePasseggero;
        private TextBox txtNomePasseggero;
        private Label lblEtaPasseggero;
        private TextBox txtEtaPasseggero;
        private Button btnCreaPasseggero;
        private Button btnContaPostiLiberi;
        private Button btnContaPostiAssegnati;
        private Button btnContaMinorenni;
        private Button btnTrovaEtaDelPiuGiovane;
        private Button btnTrovaEtaDelPiuVecchio;
        private Button button1;
        private Label lblPostiLiberi;
        private Label lblOutputPostiLiberi;
        private Label lbltxtPostiAssegnati;
        private Label lblOutputPostiAssegnati;
        private Label lbltxtNumeroDiMinorenni;
        private Label lblOutputContaMinorenni;
        private Button btnAssegnaPosto;
        private Label lblPosto;
        private TextBox txtInputPosto;
        private Button btnInserisciNuoviDati;
        private Label lblOutputAssegnaPosto;
        private Button btnEliminaPasseggero;
        private Label lblEliminaPasseggero;
        private TextBox txtInputPostoDaEliminare;
        private Label lblEtaDelPiuVecchio;
        private Label lblOutputEtaDelPiuVecchio;
        private Label lblElencoDeiPasseggeriMinorenni;
        private Label lblOutputElencoDeiPasseggeriMinorenni;
        private Label lblEtaDelPiuGiovane;
        private Label lblOutputEtaDelPiuGiovane;
        private Label lblPasseggeroDaCercare;
        private TextBox txtPasseggeroDaCercare;
        private Button btnCercaPasseggero;
        private Label lblOutputPasseggeroDaCercare;
    }
}
